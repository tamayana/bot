global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6285754675168']
global.gambar = "https://files.catbox.moe/9wibx1.jpg"
// GUNAKAN BOT DENGAN BIJAK !!!
// CREATE BY VINN-XD